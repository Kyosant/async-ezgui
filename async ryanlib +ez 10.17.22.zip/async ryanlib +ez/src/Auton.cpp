#include "Auton.hpp"

void AWP(){

}
void AWPL(){
   
}

void AWPR(){
   
}

void Elims(){
   
}

void ElimsL(){
   
}

void ElimsR(){
   
}