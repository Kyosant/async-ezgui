#pragma once
#include "main.h"

/**
 * @brief LRT AWP Auton - grabs the side mobile, then grabs a neutral mobile goal
 * 
 */
void AWP();
/**
 * @brief LRT AWP Auton - grabs the side mobile, then grabs a neutral mobile goal
 * 
 */
void AWPR();
/**
 * @brief LRT AWP Auton - grabs the side mobile, then grabs a neutral mobile goal
 * 
 */
void AWPL();

/**
 * @Auton for elimnations, drives back, loads the preload rings, then curves to the center mogo and deposit
 * 
 */
void Elims();

/**
 * @Auton for elimnations, drives back, loads the preload rings, then curves to the center mogo and deposit
 * 
 */
void ElimsR();
/**
 * @Auton for elimnations, drives back, loads the preload rings, then curves to the center mogo and deposit
 * 
 */
void ElimsL();