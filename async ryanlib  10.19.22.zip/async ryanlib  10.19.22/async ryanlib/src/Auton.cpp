#include "Auton.hpp"
#include "main.h"
#include "okapi/impl/device/controller.hpp"
#include "okapi/impl/device/controllerUtil.hpp"
#include "pros/adi.h"
#include "pros/adi.hpp"
#include "pros/llemu.hpp"
#include "pros/misc.hpp"
#include "pros/motors.h"
#include "pros/motors.hpp"
#include "pros/rtos.h"
#include "pros/rtos.hpp"
#include "ryanlib/api.hpp"
#include <cmath>

void AWP(){
 
    
}
void AWPL(){
   
}

void AWPR(){
   
}

void Elims(){
   
}

void ElimsL(){
   
}

void ElimsR(){
   
}