#include "main.h"
#include "okapi/impl/device/controller.hpp"
#include "okapi/impl/device/controllerUtil.hpp"
#include "pros/adi.h"
#include "pros/adi.hpp"
#include "pros/misc.hpp"
#include "pros/motors.h"
#include "pros/motors.hpp"
#include "pros/rtos.h"
#include "pros/rtos.hpp"
#include "ryanlib/api.hpp"
#include <cmath>


// motor and port declaeratrion 
pros::Motor lf(1, true);
pros::Motor lrb(2, true);
pros::Motor lrt(3, false);

pros::Motor rf(11, false);
pros::Motor rrb(12, false);
pros::Motor rrt(15, true);

pros::Motor cata(4, false);
pros::Motor intake(14, false);

pros::ADIDigitalIn limit('E');

pros::Controller con1 (CONTROLLER_MASTER);
okapi::Controller master(okapi::ControllerId::master);

// catapult shenanigans
void prime_cata (){
    while (!limit.get_value()) {
      cata.move_velocity(100);
      pros::delay(10);
    }
    cata.move_velocity(0);
}

void shoot_cata (){
  cata.move_velocity(100);
  pros::delay(300);

  prime_cata();
  cata.move_velocity(0);
}



ProfileConstraint moveLimit({5.3_ftps, 6_ftps2, 5_ftps2, 27_ftps3});

// TUNING
// FFVelocityController leftController(0, 0, 0, 0, 0);
// FFVelocityController rightController(0, 0, 0, 0, 0);

std::shared_ptr<ChassisController> chassis =
    ChassisControllerBuilder()
        .withMotors({-1, -2, -3}, {-11, -12, -15}) // also change later
        .withDimensions(
            {AbstractMotor::gearset::blue, 5.0 / 3.0},
            {{3.25_in, 1.25_ft}, imev5BlueTPR}) // change track diam later
        .build();

std::shared_ptr<AsyncMotionProfiler> profiler =
    AsyncMotionProfilerBuilder()
        .withOutput(chassis)
        //.withLinearController(leftController, rightController)
        .withProfiler(std::make_unique<SCurveMotionProfile>(moveLimit))
        .build();

Pneumatics Endgame('A', false);

/**
 * A callback function for LLEMU's center button.
 *
 * When this callback is fired, it will toggle line 2 of the LCD text between
 * "I was pressed!" and nothing.
 */
void on_center_button() {
  static bool pressed = false;
  pressed = !pressed;
  if (pressed) {
    Endgame.toggle();
  } else {
  }
}

// ezgui things


void auton1() {}
void auton2() {}
void auton3() {}

ez::GUI display(
    {{lf, "left front"},
     {lrb, "left rear bottom"},
     {lrt, "left rear top"},
     {rf, "right front"},
     {rrb, "right rear bottom"},
     {rrt, "right rear top"},
     {cata, "catapult"},
     {intake, "intake"}},
    

    {{"Auto 1", auton1},
     {"Auto 2", auton2},
     {"Auto 3", auton3}});

  pros::ADIDigitalIn increase('F');
  pros::ADIDigitalIn decrease('E');

  void pong_screen_task() {
    bool competition_status = false;
    while (true) {
      if (display.enabled()) {
        if (pros::competition::is_connected() ||
            pros::competition::is_autonomous())
          competition_status = true;
        else
          competition_status = false;

        if (display.auton_button_right_new()) {
          if (display.auton_page_current_get() ==
                  display.auton_amount_get() - 1 &&
              !display.pong_enabled() && !competition_status) {
            display.pong_enable();
          } else {
            display.pong_disable();
            display.auton_page_up();
          }
        } else if (display.auton_button_left_new()) {
          if (display.auton_page_current_get() == 0 &&
              !display.pong_enabled() && !competition_status) {
            display.pong_enable();
          } else {
            display.pong_disable();
            display.auton_page_down();
          }
        }

        if (competition_status && display.pong_enabled()) {
          display.pong_disable();
          display.auton_page_up();
        }
      }

      pros::delay(20);
    }
  }
  pros::Task pongScreenTask(pong_screen_task);

  //----------------------------------------------------------------

   
    
    //---------------------------

  /**
   * Runs initialization code. This occurs as soon as the program is started.
   *
   * All other competition modes are blocked by initialize; it is recommended
   * to keep execution time for this mode under a few seconds.
   */
  void initialize() {

    pros::delay(300);

    display.auton_button_limitswitch_initialize(&increase, &decrease);
    display.enable();
    display.auton_disable();
    display.auton_print();

    pros::lcd::initialize();

    pros::lcd::register_btn1_cb(on_center_button);
  }

  /**
   * Runs while the robot is in the disabled state of Field Management System or
   * the VEX Competition Switch, following either autonomous or opcontrol. When
   * the robot is enabled, this task will exit.
   */
  void disabled() {}

  /**
   * Runs after initialize(), and before autonomous when connected to the Field
   * Management System or the VEX Competition Switch. This is intended for
   * competition-specific initialization routines, such as an autonomous
   * selector on the LCD.
   *
   * This task will exit when the robot is enabled and autonomous or opcontrol
   * starts.
   */
  void competition_initialize() {}

  /**
   * Runs the user autonomous code. This function will be started in its own
   * task with the default priority and stack size whenever the robot is enabled
   * via the Field Management System or the VEX Competition Switch in the
   * autonomous mode. Alternatively, this function may be called in initialize
   * or opcontrol for non-competition testing purposes.
   *
   * If the robot is disabled or communications is lost, the autonomous task
   * will be stopped. Re-enabling the robot will restart the task, not re-start
   * it from where it left off.
   */
  void autonomous() { display.auton_call();
    //awp
    /*
    prime_cata();
    profiler->setTarget(-2_in);
    intake.move_absolute(20,100);
    profiler->waitUntilSettled();
    profiler->setTarget(6_in);
    profiler->setTarget(45_deg);
    profiler->setTarget(68_in);
    profiler->setTarget(-90_deg);
    cata_shoot();
    profiler->setTarget(-90_deg);
    intake.spin(12000)
    profiler->setTarget(-68_in);
    profiler->setTarget(45_deg);
    profiler->setTarget(-2_in);
    intake.move_absolute(20,100);
    profiler->waitUntilSettled();
    profiler->setTarget(6_in);
    */
    
    }
   

  /**
   * Runs the operator control code. This function will be started in its own
   * task with the default priority and stack size whenever the robot is enabled
   * via the Field Management System or the VEX Competition Switch in the
   * operator control mode.
   *
   * If no competition control is connected, this function will run immediately
   * following initialize().
   *
   * If the robot is disabled or communications is lost, the
   * operator control task will be stopped. Re-enabling the robot will restart
   * the task, not resume it from where it left off.
   */ 
    
   
   
    
   
   
  void opcontrol() {
    
    // drive control
    

    


  

     
    while (true) {
      
      chassis->getModel()->curvature(master.getAnalog(okapi::ControllerAnalog::leftY) , master.getAnalog(okapi::ControllerAnalog::rightX)*-1);

     //intake

      if (con1.get_digital(DIGITAL_L1)){
        //intake
        intake.move_velocity(-140);

      }else if (con1.get_digital(DIGITAL_L2)){
        //rollers
        intake.move_velocity(170);

      }else{
        intake.brake();
      }

      //cata

      if (con1.get_digital(DIGITAL_R2)){
        pros::Task cata (prime_cata); 

      }else if (con1.get_digital(DIGITAL_R1)){
        pros::Task cata (shoot_cata);

      
      }else{
        cata.move_velocity(0);
        cata.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
        cata.brake();
        pros::delay(10);
      }

    pros::delay(2);

    }
  }