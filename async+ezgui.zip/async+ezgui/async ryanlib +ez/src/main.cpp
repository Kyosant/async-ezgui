#include "main.h"
#include "pros/misc.hpp"
#include "ryanlib/api.hpp"

ProfileConstraint moveLimit({5.3_ftps, 6_ftps2, 5_ftps2, 27_ftps3});

// TUNING
// FFVelocityController leftController(0, 0, 0, 0, 0);
// FFVelocityController rightController(0, 0, 0, 0, 0);

std::shared_ptr<ChassisController> chassis =
    ChassisControllerBuilder()
        .withMotors({14, 15, 16}, {-17, -18, -20}) // also change later
        .withDimensions(
            {AbstractMotor::gearset::blue, 5.0 / 3.0},
            {{3.25_in, 1.25_ft}, imev5BlueTPR}) // change track diam later
        .build();

std::shared_ptr<AsyncMotionProfiler> profiler =
    AsyncMotionProfilerBuilder()
        .withOutput(chassis)
        //.withLinearController(leftController, rightController)
        .withProfiler(std::make_unique<SCurveMotionProfile>(moveLimit))
        .build();

Pneumatics Endgame('A', false);

/**
 * A callback function for LLEMU's center button.
 *
 * When this callback is fired, it will toggle line 2 of the LCD text between
 * "I was pressed!" and nothing.
 */
void on_center_button() {
  static bool pressed = false;
  pressed = !pressed;
  if (pressed) {
    Endgame.toggle();
  } else {
  }
}

// ezgui things
pros::Motor lf(11, true);
pros::Motor lrb(12, true);
pros::Motor lrt(13, true);
pros::Motor rf(14, true);
pros::Motor rrb(20, false);
pros::Motor rrt(19, false);
pros::Motor cata(18, false);
pros::Motor intake(17, false);

void auton1() {}
void auton2() {}
void auton3() {}

ez::GUI display(
    {{lf, "left front"},
     {lrb, "left rear bottom"},
     {lrt, "left rear top"},
     {rf, "right front"},
     {rrb, "right rear bottom"},
     {rrt, "right rear top"},
     {cata, "catapult"},
     {intake, "intake"}},
    

    {{"Auto 1", auton1},
     {"Auto 2", auton2},
     {"Auto 3", auton3}});

  pros::ADIDigitalIn increase('F');
  pros::ADIDigitalIn decrease('E');

  void pong_screen_task() {
    bool competition_status = false;
    while (true) {
      if (display.enabled()) {
        if (pros::competition::is_connected() ||
            pros::competition::is_autonomous())
          competition_status = true;
        else
          competition_status = false;

        if (display.auton_button_right_new()) {
          if (display.auton_page_current_get() ==
                  display.auton_amount_get() - 1 &&
              !display.pong_enabled() && !competition_status) {
            display.pong_enable();
          } else {
            display.pong_disable();
            display.auton_page_up();
          }
        } else if (display.auton_button_left_new()) {
          if (display.auton_page_current_get() == 0 &&
              !display.pong_enabled() && !competition_status) {
            display.pong_enable();
          } else {
            display.pong_disable();
            display.auton_page_down();
          }
        }

        if (competition_status && display.pong_enabled()) {
          display.pong_disable();
          display.auton_page_up();
        }
      }

      pros::delay(20);
    }
  }
  pros::Task pongScreenTask(pong_screen_task);

  //----------------------------------------------------------------

  /**
   * Runs initialization code. This occurs as soon as the program is started.
   *
   * All other competition modes are blocked by initialize; it is recommended
   * to keep execution time for this mode under a few seconds.
   */
  void initialize() {

    pros::delay(300);

    display.auton_button_limitswitch_initialize(&increase, &decrease);
    display.enable();
    display.auton_disable();
    display.auton_print();

    pros::lcd::initialize();

    pros::lcd::register_btn1_cb(on_center_button);
  }

  /**
   * Runs while the robot is in the disabled state of Field Management System or
   * the VEX Competition Switch, following either autonomous or opcontrol. When
   * the robot is enabled, this task will exit.
   */
  void disabled() {}

  /**
   * Runs after initialize(), and before autonomous when connected to the Field
   * Management System or the VEX Competition Switch. This is intended for
   * competition-specific initialization routines, such as an autonomous
   * selector on the LCD.
   *
   * This task will exit when the robot is enabled and autonomous or opcontrol
   * starts.
   */
  void competition_initialize() {}

  /**
   * Runs the user autonomous code. This function will be started in its own
   * task with the default priority and stack size whenever the robot is enabled
   * via the Field Management System or the VEX Competition Switch in the
   * autonomous mode. Alternatively, this function may be called in initialize
   * or opcontrol for non-competition testing purposes.
   *
   * If the robot is disabled or communications is lost, the autonomous task
   * will be stopped. Re-enabling the robot will restart the task, not re-start
   * it from where it left off.
   */
  void autonomous() { display.auton_call(); }

  /**
   * Runs the operator control code. This function will be started in its own
   * task with the default priority and stack size whenever the robot is enabled
   * via the Field Management System or the VEX Competition Switch in the
   * operator control mode.
   *
   * If no competition control is connected, this function will run immediately
   * following initialize().
   *
   * If the robot is disabled or communications is lost, the
   * operator control task will be stopped. Re-enabling the robot will restart
   * the task, not resume it from where it left off.
   */
  void opcontrol() {
    profiler->setTarget(2_ft);
    profiler->setTarget(90_deg);
    // drive control
    pros::Motor lf (15, true);
    pros::Motor lrb (16, true);
    pros::Motor lrt (17, true);
    pros::Motor rf (18);
    pros::Motor rrb (19);
    pros::Motor rrt (20);
    pros::Motor catapult (1);
    pros::Motor intake (2);
    pros::Controller con1 (CONTROLLER_MASTER);
    //-----------------------------------------------

    while (true) {
      int power = con1.get_analog(ANALOG_LEFT_Y);
      int turn = con1.get_analog(ANALOG_LEFT_X);
      int left = power + turn;
      int right = power - turn;
      lf.move(left);
      lrb.move(left);
      lrt.move(left);
      rf.move(right);
      rrb.move(right);
      rrt.move(right);

      if (con1.get_digital(DIGITAL_R1)&&(con1.get_digital(DIGITAL_R2) )){

      }

      pros::delay(2);
    }

    

  }
